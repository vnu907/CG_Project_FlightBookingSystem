import React from 'react'
import Navbar from '../components/Navbar'

function SignIn() {
  return (
    <div>
    <Navbar/>
    </div>
  )
}

export default SignIn