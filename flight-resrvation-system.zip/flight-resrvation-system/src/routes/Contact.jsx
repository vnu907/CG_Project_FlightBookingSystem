import React from 'react';
import Navbar from '../components/Navbar';

const Contact = () => {
  return (
    <>
    <div>
    <Navbar/>
      <h2>Contact Page</h2>
      <p>This is the Contact page content.</p>
    </div>
    </>
  );
};

export default Contact;
